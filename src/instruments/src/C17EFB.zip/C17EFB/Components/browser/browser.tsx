import React from 'react';

export const Browser = () => {
	return (
		<iframe
			width="1040"
			height="810"
			src="https://www.bing.com/"
			frameBorder="0"
		></iframe>
	);
};
