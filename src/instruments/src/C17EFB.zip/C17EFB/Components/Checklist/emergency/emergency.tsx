import React from 'react';
import './emergency.scss';

export const Emergency = () => {
	return (
		<div className="emergencyContainer">
			<h1 style={{ marginTop: 25, marginLeft: 400, color: '#1B93FF' }}>
				Coming soon
			</h1>
		</div>
	);
};
